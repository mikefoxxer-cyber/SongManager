package com.songmaster.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SongViewerScreen(title: String, content: String) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = title, fontSize = 28.sp)
        Text(text = content, modifier = Modifier.padding(top = 12.dp))
    }
}
