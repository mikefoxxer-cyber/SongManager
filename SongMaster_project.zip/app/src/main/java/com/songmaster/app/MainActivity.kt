package com.songmaster.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.songmaster.app.ui.SongEditorScreen
import com.songmaster.app.ui.SongListScreen
import com.songmaster.app.ui.theme.SongMasterTheme
import com.songmaster.app.viewmodel.SongViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: SongViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SongMasterTheme {
                var showEditor by remember { mutableStateOf(false) }
                Scaffold(
                    topBar = {
                        TopAppBar(title = { Text("SongMaster") })
                    },
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showEditor = true }) {
                            Text("+")
                        }
                    }
                ) { padding ->
                    Box(modifier = Modifier.padding(padding)) {
                        if (showEditor) {
                            SongEditorScreen(viewModel) {
                                showEditor = false
                                Toast.makeText(this@MainActivity, "Song saved", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            SongListScreen(viewModel) { songId ->
                                // For simplicity, show viewer via toast (could navigate)
                                Toast.makeText(this@MainActivity, "Open song id: $songId", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }
}
