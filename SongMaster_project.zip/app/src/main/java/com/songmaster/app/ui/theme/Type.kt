package com.songmaster.app.ui.theme

import androidx.compose.material.Typography

val Typography = Typography()
