package com.songmaster.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.songmaster.app.data.Song
import com.songmaster.app.viewmodel.SongViewModel

@Composable
fun SongEditorScreen(viewModel: SongViewModel, onSave: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text("Tags (comma)") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Content") , }, modifier = Modifier
            .fillMaxWidth()
            .height(220.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            if (title.isNotBlank()) {
                viewModel.addSong(Song(title = title, content = content, tags = tags))
                onSave()
            }
        }) {
            Text("Save Song")
        }
    }
}
