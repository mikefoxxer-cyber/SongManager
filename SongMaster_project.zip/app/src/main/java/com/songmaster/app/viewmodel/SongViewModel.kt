package com.songmaster.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.songmaster.app.data.AppDatabase
import com.songmaster.app.data.Song
import kotlinx.coroutines.launch

class SongViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).songDao()
    val allSongs: LiveData<List<Song>> = dao.getAll()

    fun addSong(song: Song) = viewModelScope.launch {
        dao.insert(song)
    }
}
