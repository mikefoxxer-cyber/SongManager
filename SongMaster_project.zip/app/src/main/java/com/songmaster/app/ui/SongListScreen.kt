package com.songmaster.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.songmaster.app.viewmodel.SongViewModel

@Composable
fun SongListScreen(viewModel: SongViewModel, onOpen: (Long) -> Unit) {
    val songs = viewModel.allSongs.collectAsState(initial = emptyList())
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        for (song in songs.value) {
            Text(text = song.title, modifier = Modifier
                .clickable { onOpen(song.id) }
                .padding(12.dp))
            Divider()
        }
    }
}
