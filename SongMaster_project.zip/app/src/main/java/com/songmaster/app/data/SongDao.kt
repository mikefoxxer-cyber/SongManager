package com.songmaster.app.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface SongDao {
    @Insert
    suspend fun insert(song: Song): Long

    @Query("SELECT * FROM songs ORDER BY id DESC")
    fun getAll(): LiveData<List<Song>>

    @Query("SELECT * FROM songs WHERE tags LIKE '%' || :tag || '%' ORDER BY id DESC")
    fun getByTag(tag: String): LiveData<List<Song>>
}
